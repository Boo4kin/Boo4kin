import streamlit as st
from load_data import *
import pandas as pd

@st.cache_data
def load_books_df():
    return load_books()

def draw_row(row):
    book_entry = st.columns((1, 6), gap='medium')
    title = row['Book-Title']
    author = row['Book-Author']
    isbn = row['ISBN']
    with book_entry[0]:
        st.image(row['Image-URL-M'])
    with book_entry[1]:
        st.text(f'{title}\n{author}')
        inner_row = st.columns((2, 5), gap='medium')
        with inner_row[0]:
            sel_idx = st.session_state.favs[isbn]-1
            user_rating = st.selectbox("Rating", list(range(1,11)), index=sel_idx, key=f"rating_{isbn}")
            if user_rating:
                st.session_state.favs[isbn] = user_rating

st.write("# Welcome to Bookshelf!")

if 'books' not in st.session_state:
    st.session_state.books = load_books_df()

if 'favs' not in st.session_state:
    st.session_state['favs'] = {}

if len(st.session_state['favs']) == 0:
    st.write("Nothing here yet...")
else:
    books_df = st.session_state.books
    for index, row in books_df[books_df['ISBN'].isin(st.session_state['favs'])].iterrows():
        draw_row(row)
