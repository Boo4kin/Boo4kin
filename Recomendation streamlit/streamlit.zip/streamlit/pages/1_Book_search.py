import streamlit as st
from load_data import *
import pandas as pd

@st.cache_data
def load_books_df():
    return load_books()

def draw_row(row):
    book_entry = st.columns((1, 6), gap='medium')
    title = row['Book-Title']
    author = row['Book-Author']
    isbn = row['ISBN']
    with book_entry[0]:
        st.image(row['Image-URL-M'])
    with book_entry[1]:
        st.text(f'{title}\n{author}')
        is_fav = isbn in st.session_state['favs']
        swt_fav = st.toggle("Add to shelf", value=is_fav, key=isbn)
        if swt_fav:
            st.session_state['favs'][isbn] = 5
        elif is_fav:
            st.session_state['favs'].pop(isbn, None)

def book_search(df, search_str):
    m1 = df['Book-Title'].str.lower().str.contains(search_str.lower())
    m2 = df['Book-Author'].str.lower().str.contains(search_str.lower())
    return df[m1 | m2]

if 'favs' not in st.session_state:
    st.session_state['favs'] = {}

if 'books' not in st.session_state:
    st.session_state.books = load_books_df()

st.write("# Search")

text_search = st.text_input("Search books", "")
if text_search:
    search_df = book_search(st.session_state.books, text_search)
    for index, row in search_df.head(10).iterrows():
        draw_row(row)
