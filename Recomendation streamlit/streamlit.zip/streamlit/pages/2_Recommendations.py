import streamlit as st
from load_data import *
import pandas as pd
import pickle
from surprise import  Dataset, Reader

@st.cache_resource
def load_model():
    with open('model.pkl','rb') as f:
        model = pickle.load(f)
    return model

def get_predictions():
    reader = Reader(rating_scale=(1, 10))
    best_model = load_model()
    ratings = load_ratings()
    new_user_id = len(ratings)
    new_user_ratings = []
    for isbn, book_rating in st.session_state.favs.items():
        new_user_ratings.append((new_user_id, isbn, book_rating))

    new_user_ratings_df = pd.DataFrame(new_user_ratings, columns=['User-ID', 'ISBN', 'Book-Rating'])
    updated_ratings = pd.concat([ratings, new_user_ratings_df], ignore_index=True)
    updated_data = Dataset.load_from_df(updated_ratings, reader)
    updated_trainset = updated_data.build_full_trainset()

    best_model.fit(updated_trainset)

    rated_items = set(updated_ratings[updated_ratings['User-ID'] == new_user_id]['ISBN'])
    unrated_items = set(updated_ratings[updated_ratings['ISBN'].apply(lambda x: x not in rated_items)]['ISBN'].tolist())

    # Предсказываем рейтинг для этих записей
    predictions = []
    for item_id in unrated_items:
        prediction = best_model.predict(new_user_id, item_id)
        predictions.append((item_id, prediction.est))

    # Отсортируем предсказания по рейтингу в убывающем порядке
    predictions_sorted = sorted(predictions, key=lambda x: x[1], reverse=True)
    return predictions_sorted

def draw_row(row, rating):
    book_entry = st.columns((1, 6), gap='medium')
    title = row['Book-Title']
    author = row['Book-Author']
    isbn = row['ISBN']
    with book_entry[0]:
        st.image(row['Image-URL-M'])
    with book_entry[1]:
        st.text(f'{title}\n{author}')
        inner_row = st.columns((2, 5), gap='medium')
        with inner_row[0]:
            st.write(rf"#### Rating: {rating}")

def get_recommendations(top_n):
    books = st.session_state.books
    predictions_sorted = get_predictions()
    top_recommendations = [(x[0], round(x[1],1)) for x in predictions_sorted[:top_n]]

    for isbn, rating in top_recommendations:
        row = books.loc[books['ISBN'] == isbn].iloc[0]
        draw_row(row, rating)

st.session_state.model = load_model()

if 'books' not in st.session_state:
    st.session_state.books = load_books()

if 'ratings' not in st.session_state:
    st.session_state.ratings = load_ratings()

if 'favs' not in st.session_state:
    st.session_state['favs'] = {}

books_df = st.session_state['books']

st.write("# My Books")

if len(st.session_state['favs']) == 0:
    st.markdown(
    """
    ## No books yet...
    Add books to the Bookshelf first
    """
    )
else:
    upper_col = st.columns((3, 6), gap='medium')
    with upper_col[0]:
        n_rec = st.number_input("Number of books to recommend", min_value=5, max_value=50, step=5)
    with upper_col[1]:
        rec_btn = st.button("GO!", type='secondary')
    if rec_btn:
        get_recommendations(n_rec)